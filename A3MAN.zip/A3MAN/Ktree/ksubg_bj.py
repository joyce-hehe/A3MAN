# encoding: utf-8
# created by nan May 3

import ctypes
import os
import sys
import math
import copy
import random
import time
import unittest
from UnionFind import UnionFind
from os.path import join
sys.setrecursionlimit(25000)

INF = 1e+10  
EPS = 1e-6   
# ALPHA = 0.15


class AttributeGraph:
    def __init__(self):  
        self.attgraph = {}  
        self.att = {}


_mod = ctypes.cdll.LoadLibrary('./libmckp.so')  
_mckp_01 = _mod.mckp_01  
_mckp_01.argtypes = (ctypes.POINTER(ctypes.c_int), ctypes.c_int)
_mckp_01.restype = ctypes.POINTER(ctypes.c_int)


def mckp_01(values, K):  

    val = _mckp_01(((ctypes.c_int)*len(values))(*values), K)  
    if val[0] == -1:
        return []
    else:
        return [val[i] for i in range(values[0] + 2)]


def bruteforce(data, K):  
    
    d = copy.deepcopy(data)  
    num = [0 for i in range(len(d))]
    len_num = len(d)
    cat = {}
    while len_num > 0 and num[len_num-1] <= len(d[len_num-1]):
        w = 0
        p = 0
        for i in range(len_num):
            if num[i] < len(d[i]):
                w += d[i][num[i]][2]
                p += d[i][num[i]][1]
        if w <= K:
            if p not in cat:
                cat[p] = []
            cat[p].append([[num[i] for i in range(len_num)], w])
        num[0] += 1
        for i in range(len_num):
            if num[i] > len(d[i]) and i+1 < len_num:
                num[i] = 0
                num[i+1] += 1
    if len(cat) > 0:
        max_p = max(cat.keys())
        ls = cat[max_p]
        temp = sorted(ls, key=lambda xx:xx[1])
        num = temp[0][0]
        return [temp[0][1], [d[i][num[i]][0] for i in range(len_num) if num[i] < len(d[i])]]
    else:
        return []


class Node:
    def __init__(self, name, pvalue, nchild, child):  
        self.name = name
        self.pvalue = pvalue
        self.nchild = nchild
        self.child = child


class Optim:
    def __init__(self, alpha, Gpv, app, curi, Fi=0):  
        self.alpha = alpha
        self.Gpv = Gpv
        self.app = app
        self.curi = curi
        self.Fi = 0
        self.q = 0  

    def setq(self):  
        self.q = 0
        for item in self.Gpv:  
            if self.Gpv[item] < self.alpha[self.curi]:
                self.q += 1


def BJ(alpha, N_a, N):

    if N == 0:
        return 0
    aa = N_a * 1.0 / N
    bb = alpha
    return N * (aa*math.log((aa/bb) + EPS) + (1-aa)*math.log(((1-aa)/(1-bb)) + EPS))


def HC(alpha, N_a, N):

    return (N_a - N*alpha) / (math.sqrt(N*alpha*(1-alpha)))


def g(v, alpha):  

    if v.pvalue < alpha:
        return 0
    else:
        return 1


def maxDeV(v, l, DeS, DeA, DeV):

   temp = []
   if l in DeS[v.name]:
       temp.append(DeS[v.name][l])
   if l in DeA[v.name]:
       temp.append(DeA[v.name][l])
   if len(temp) > 0:
       DeV[v.name][l] = max(temp) 


def maxwsum(childb):

    wsum2 = 0
    dichild = {}
    count = childb[0]
    for i in range(childb[0]):
        dichild[i] = {}
        for j in range(childb[1+i]):
            temp = []
            count += 1
            temp.append(childb[count])
            count += 1
            temp.append(childb[count])
            count += 1
            temp.append(childb[count])
            dichild[i][j] = temp

    for j in range(childb[0]):
        last = dichild[j][childb[1+j]-1]
        for i in range(childb[1+j]-1):
            if dichild[j][i][1] >= last[1]:
                if dichild[j][i][1] > last[1] or dichild[j][i][2] < last[2]:
                    last = dichild[j][i]
        wsum2 += last[2]
    return wsum2


def maxtree(v, K, DeS, DeA, DeV, isbrute, galpha, opt, x):  

    terval = 0
    for i in range(v.nchild):
        temp = maxtree(v.child[i], K, DeS, DeA, DeV, isbrute, galpha, opt, x)
        if temp[0] == -1:
            return temp
        terval += temp[0]

    # print('[maxtree] current node:', v.name)

    if v.name not in DeS:
        DeS[v.name] = {}
    if v.name not in DeA:
        DeA[v.name] = {}
    if v.name not in DeV:
        DeV[v.name] = {}
    
    gv = g(v, galpha)
    
    if v.nchild == 0:
        DeA[v.name][gv] = 1 - gv
        DeV[v.name][gv] = 1 - gv
    else:
        childa = []
        childmckp = []
        map = {}
        childcount = 0
        # childdt = {i:0 for i in range(v.nchild)}
        childdt = {}
        for i in range(v.nchild):
            childdt[i] = 0
        for i in range(v.nchild):
            temp = []
            isfirst = True
            for j in range(K+1):
                if j in DeA[v.child[i].name]:
                    temp.append([str(i)+'_'+str(j), DeA[v.child[i].name][j], j])

                    if isfirst:
                        isfirst = False
                        childmckp.extend([childcount, 0, 0])
                        map[childcount] = 'dummy'
                        childcount += 1
                        childdt[i] += 1

                    childmckp.extend([childcount, DeA[v.child[i].name][j], j])
                    map[childcount] = str(i)+'_'+str(j)
                    childcount += 1
                    childdt[i] += 1
            if len(temp) > 0:
                childa.append(temp)

        if not isbrute:
            childb = [len(childa)]
            for i in range(v.nchild):
                if childdt[i] == 0:
                    continue
                childb.append(childdt[i])
            childb.extend(childmckp)
            wsum2 = maxwsum(childb)

        for l in range(K+1):

            temp = [DeV[vi][l] for vi in [v.child[i].name for i in range(v.nchild)] if l in DeV[vi]]
            if len(temp) > 0:
                DeS[v.name][l] = max(temp)

            if isbrute:
                ret = bruteforce(childa, l-gv)
            else:
                temp = []
                # print '[maxtree] wsum2:', wsum2, ' K = ', K, ' l-gv = ', l-gv, childb
                if wsum2 >= l-gv and l-gv >= 0:
                    temp = mckp_01(childb, l-gv)
                # print '[maxtree] mckp:', temp
                classes = len(childa)
                ret = []
                if len(temp) > 0:
                    ret = [temp[classes+1], [map[temp[i]] for i in range(classes) if map[temp[i]] != 'dummy']]
                    # print '[maxtree] mckp ret:', ret
            
            if len(ret) > 0:
                lmax = gv + ret[0]
                lval = 1 - gv
                lx = {}
                for idx in range(len(ret[1])):
                    i = int(ret[1][idx].split('_')[0])
                    j = int(ret[1][idx].split('_')[1])
                    lval += DeA[v.child[i].name][j]
                    lx[v.child[i]] = j
                if lmax not in DeA[v.name] or lval > DeA[v.name][lmax]:
                    DeA[v.name][lmax] = lval
                    if v not in x:
                        x[v] = {}
                    if lmax not in x[v]:
                        x[v][lmax] = lx
                    maxDeV(v, lmax, DeS, DeA, DeV)
        # non optimize
        # DeA[v.name][l] = lval
        # x[v][l] = lx
            maxDeV(v, l, DeS, DeA, DeV)

    temp = [DeA[v.name][l] for l in DeA[v.name]]
    terval += 1 - g(v, galpha)

    if opt.curi >= 0 and len(temp) > 0:
        opt.q = opt.q - (terval - max(temp))
        phiscore = 0
        if opt.q > 0:
            if opt.app == 'bj':
                phiscore = BJ(opt.alpha[opt.curi], opt.q, opt.q)
            if opt.app == 'hc':
                phiscore = HC(opt.alpha[opt.curi], opt.q, opt.q)
        if phiscore < opt.Fi:
            return [-1, v]

    return [terval, v]


def getmaxk(v, K, DeV):  # 

    so = [-1, 0]
    for i in range(K+1):
        if i not in DeV[v.name]:
            continue
        if DeV[v.name][i] > so[0]:
            so[0] = DeV[v.name][i]
            so[1] = i
    return so[1]
        

def getsubtree(v, K, x):  #
    
    S = []
    # print('[getsubtree] current node:', v.name, v.pvalue, K)

    if v in x and K in x[v]:
        for vchild in x[v][K].keys():
            S.extend(getsubtree(vchild, x[v][K][vchild], x))
            
    if v.name not in S:
        S.append(v.name)
    return S
    

def KCardTree(vlis, K, DeS, DeA, DeV, isbrute, galpha, opt, x, ismax=True):  

    if ismax: 
        steiner = maxtree(vlis[0], K, DeS, DeA, DeV, isbrute, galpha, opt, x)
        vlis[0] = steiner[1]
    v = vlis[0]

    # print('kcardtree:', v)
    k = getmaxk(v, K, DeV)
    while k in DeS[v.name] and k in DeA[v.name] and DeS[v.name][k] > DeA[v.name][k] or k not in DeA[v.name]:
        temp = []
        for vi in v.child:
            if k in DeV[vi.name]:
                temp.append([DeV[vi.name][k], vi])
        so = [-1, []]
        for i in range(len(temp)):
            if temp[i][0] > so[0]:
                so[0] = temp[i][0]
                so[1] = temp[i][1]
        if so[0] == -1:
            break
        v = so[1]

    return getsubtree(v, k, x)

#G最小生成树#
def MinimumSpanningTree(G):
    for u in G:
        for v in G[u]:
            if G[u][v] != G[v][u]:
                raise ValueError("MinimumSpanningTree: asymmetric weights")

    subtrees = UnionFind()
    tree = []
    for W,u,v in sorted((G[u][v],u,v) for u in G for v in G[u]):
        if subtrees[u] != subtrees[v]:
            tree.append((u,v))
            subtrees.union(u,v)
    return tree

#子树#
def SubTree(v, edges, Gpv, colornode):
    i = len(edges) - 1
    nchild = 0
    childlis = []

    while i >= 0:
        if i in colornode:
            i -= 1
            continue
        if v == edges[i][0]:
            child = edges[i][1]
            colornode[i] = 1
            nchild += 1
            childlis.append(SubTree(child, edges, Gpv, colornode))
        if v == edges[i][1]:
            child = edges[i][0]
            colornode[i] = 1
            nchild += 1
            childlis.append(SubTree(child, edges, Gpv, colornode))
        i -= 1

    treenode = Node(str(v), Gpv[v], nchild, childlis)
    return treenode


"""
MAIN procedure
Input G, Gpv and Ground Truth
"""

#############Input G, Gpv and GroundTruth###################


def generateG(attributegraph):
    attgraph = attributegraph.attgraph

    G = {}
    for nodea in attgraph:
        for nodeb in attgraph[nodea]:
            if nodea not in G:  
                G[nodea] = {}
            G[nodea][nodeb] = 1
            if nodeb not in G:
                G[nodeb] = {}
            G[nodeb][nodea] = 1
    return G


def generateGpv(attributegraph):
    att = attributegraph.att
    Gpv = {}
    for node in att:
        Gpv[node] = att[node]

    return Gpv

############################################################

#广度优先树#
def getbfstree(G, Gpv, v, T):

    nchild = 0
    childlis = []

    temp = []
    for vi in G[v]:
        if vi not in T:
            T[vi] = 1
            temp.append(vi)

    # print g.nodes()
    for vi in temp:
        nchild += 1
        item = getbfstree(G, Gpv, vi, T)
        childlis.append(item)
    treenode = Node(str(v), Gpv[v], nchild, childlis)  
    return treenode

#广度优先树#
def IBFS(G, Gpv, v):

    T = {v:1}
    return getbfstree(G, Gpv, v, T) 


#调用最小生成树和子树#
def IRST(G, Gpv, v):

    for i in G:
        for j in G[i]:
            temp = random.random()
            G[i][j] = temp
            G[j][i] = temp
    treeedges = MinimumSpanningTree(G)
    treenode = SubTree(v, treeedges, Gpv, {})
    return treenode

#迪杰斯特拉#
def dijstg(G, src, previous, d):
    if src not in G:
        raise TypeError('the root of the shortest path tree cannot be found in the G')
    for v in G:
        d[v] = float('inf')
    d[src] = 0
    # Q = {v:1 for v in G}
    Q = {}
    for v in G:
        Q[v] = 1
    while len(Q) > 0:
        # temp = {v:d[v] for v in Q}
        temp = {}
        for v in Q:
            temp[v] = d[v]
        u = min(temp, key=temp.get)
        del Q[u]
        # print('dijstg:', u, len(Q))
        for v in G[u]:
            if v not in Q:
                continue
            new_distance = d[u] + G[u][v]
            if new_distance < d[v]:
                d[v] = new_distance
                previous[v] = u


def ISTG(G, Gpv, vroot, galpha):

    v = vroot
    G1 = copy.deepcopy(G)
    # S = {v:1 for v in Gpv if Gpv[v] < galpha}
    S = dict([(v,1) for v in Gpv if Gpv[v] < galpha])
    s0 = -1
    for u in G1:
        if u in S:
            G1[u][s0] = 0
        for v in G1[u]:
            G1[u][v] = 1
    G1[s0] = {}
    for v in S:
        G1[s0][v] = 0

    # print(S)
    # print(galpha)

    previous = {}
    d = {}
    dijstg(G1, s0, previous, d)
    # N_S = {v:{v:[0, [v]]} for v in S}
    N_S = {}
    for v in S:
        N_S[v] = {v: [0, [v]]}

    com = [v for v in G if v not in S]
    for v in com:
        # print('normal:', v)
        dis = d[v]
        path = [v]
        u = previous[v]
        while u not in S:
            path.append(u)
            u = previous[u]
        path.append(u)
        N_S[u][v] = [dis, path]

    maps = {}
    for u in N_S:
        for v in N_S[u]:
            maps[v] = u

    G2 = {}
    for u in G1:
        for v in G1[u]:
            if u == s0 or v == s0 or u == v or u not in maps or v not in maps:
                continue
            if maps[u] == maps[v]:
                continue
            if maps[u] not in G2:
                G2[maps[u]] = {}
            if maps[v] not in G2[maps[u]]:
                G2[maps[u]][maps[v]] = []
            temp = [item for item in N_S[maps[u]][u][1]]
            temp1 = [item for item in N_S[maps[v]][v][1]]
            temp.reverse()
            # temp1.reverse()
            temp.extend(temp1)
            if temp is None:
                del G2[maps[u]][maps[v]]
                continue
            G2[maps[u]][maps[v]].append([N_S[maps[u]][u][0] + G[u][v] + N_S[maps[v]][v][0], temp])
    G2dis = copy.deepcopy(G2)
    for u in G2:
        for v in G2[u]:
            if len(G2[u][v]) > 0:
                idx = float('inf')
                for item in G2[u][v]:
                    if item[0] < idx:
                        G2dis[u][v] = item[1]
                        idx = item[0]
                G2[u][v] = idx

    treeedges = MinimumSpanningTree(G2)

    G3 = {}
    for edge in treeedges:
        temp = []
        # print(edge, G2dis[edge[0]][edge[1]])
        if edge[1] in G2dis[edge[0]] and len(G2dis[edge[0]][edge[1]]) > 0:
            temp.extend(G2dis[edge[0]][edge[1]])
        for i in range(len(temp)-1):
            item = temp[i]
            if item not in G3:
                G3[item] = {}
            G3[item][temp[i+1]] = G1[item][temp[i+1]]
            if temp[i+1] not in G3:
                G3[temp[i+1]] = {}
            G3[temp[i+1]][item] = G1[temp[i+1]][item]

    treeedges = MinimumSpanningTree(G3)

    treenode = SubTree(vroot, treeedges, Gpv, {})
    return treenode


def isna(pv, galpha):

    if pv < galpha:
        return 1
    else:
        return 0


def dij(G, Gpv, src, app, previous, d, galpha):
    if src not in G:
        raise TypeError('the root of the shortest path tree cannot be found in the G')
    for v in Gpv:
        d[v] = [float('inf'), min(Gpv[v], galpha), isna(Gpv[v], galpha), 1]
    d[src][0] = 0
    # Q = {v:1 for v in Gpv}
    Q = {}
    for v in G:
        Q[v] = 1
    while len(Q) > 0:
        # temp = {v:d[v][0] for v in Q}
        temp = {}
        for v in Q:
            temp[v] = d[v]
        u = min(temp, key=temp.get)
        del Q[u]
        for v in G[u]:
            if v not in Q:
                continue
            alpha = max(d[u][1], min(Gpv[v], galpha))
            N_a = d[u][2] + isna(Gpv[v], galpha)
            N = d[u][3] + 1
            if app == 'bj':
                new_distance = [math.exp(-BJ(alpha, N_a, N)), alpha, N_a, N]
            if app == 'hc':
                new_distance = [math.exp(-HC(alpha, N_a, N)), alpha, N_a, N]
            if new_distance[0] < d[v][0]:
                d[v] = new_distance
                previous[v] = u


def getgeotree(spantree, Gpv, v):

    nchild = 0
    childlis = []
    for u in spantree[v]:
        childlis.append(getgeotree(spantree, Gpv, u))
        nchild += 1
    treenode = Node(v, Gpv[int(v)], nchild, childlis)
    return treenode


def IGEO(G, Gpv, rootg, app, galpha):

    spantree = {rootg:{}}

    distances = {}
    predecessors = {}
    dij(G, Gpv, rootg, app, predecessors, distances, galpha)
    for v in predecessors:
        u = predecessors[v]
        if u not in spantree:
            spantree[u] = {}
        if v not in spantree:
            spantree[v] = {}
        spantree[u][v] = 1

    treenode = getgeotree(spantree, Gpv, rootg)
    return treenode


def readsetting():
    data = [rec for rec in open('Ktree/setting.txt').read().split('\n') if len(rec) > 0 and rec[0] != '#']
    para = {}
    for rec in data:
        if 'seednum' in rec or 'numnorm' in rec:
            para[rec.split('=')[0]] = int(rec.split('=')[1])
        if 'ALPHAMAX' in rec:
            para[rec.split('=')[0]] = float(rec.split('=')[1])
        if 'apptree' in rec:
            para[rec.split('=')[0]] = rec.split('=')[1]
    return para    


def budgetK(attributegraph,ALPHAMAX):  

    para = readsetting()  
    # print('parameters:', para)

    apptree = para['apptree'] if 'apptree' in para else 'stg'  
    myfile = ''
    seednum = para['seednum'] if 'seednum' in para else 1
    UALPHA = [ALPHAMAX]
    numnorm = para['numnorm'] if 'numnorm' in para else 31
    #ALPHAMAX = para['ALPHAMAX'] if 'ALPHAMAX' in para else 0.15
    app = 'bj'
    isbrute = False
    G = generateG(attributegraph)  
    Gpv = generateGpv(attributegraph) 
    RUNTIME = []
    NPSS = []

    ualpha = {}  
    for u in Gpv:  
        if Gpv[u] < ALPHAMAX:
            ualpha[float('%0.2f'%Gpv[u])] = 0 
    ualpha = ualpha.keys()  
    ualpha.append(ALPHAMAX)  
    ualpha.sort()  
    ualpha.reverse() 
    # print(ualpha)

    myfile = ''  

    del ualpha[len(ualpha)-1]  

    for cc in range(seednum):
        if len(UALPHA) == 0:  
            continue
        opt = Optim(UALPHA, Gpv, app, 0) 

        isheualpha = True
        rootg = 0
        rootnode = None
        rootlis = []

        for ialpha in range(len(UALPHA)):
            galpha = UALPHA[ialpha] 
            opt.curi = ialpha
            opt.setq() 

            if isheualpha:
                temp = [v for v in Gpv if Gpv[v] < galpha]  
                rootg = temp[random.randint(0, len(temp)-1)]  
                # print('build tree...')
                # print('root:', rootg, 'alpha:', galpha)
                treebuildstart = time.time()  
                if apptree == 'bfs':
                    rootnode = IBFS(G, Gpv, rootg)
                elif apptree == 'rst':
                    rootnode = IRST(G, Gpv, rootg)
                elif apptree == 'stg':
                    rootnode = ISTG(G, Gpv, rootg, galpha)
                elif apptree == 'geo':
                    rootnode = IGEO(G, Gpv, rootg, 'bj', galpha)
                else:
                    #print('app ERROR...')
                    sys.exit()
            treebuildend = time.time()  
            RUNTIME.append([treebuildend-treebuildstart])
            rootlis = [rootnode]  
            isheualpha = False

            # print('[main] Select the root node:', rootg, rootnode.name)  

            x = {}
            DeS = {}
            DeA = {}
            DeV = {}

            pr = []
            runstart = []
            runend = []
            result = []
            isOPTK = True
            itr = 0
            KLIS = [i for i in range(numnorm)]  
            KLIS.reverse()
            for Kcon in KLIS:  
                if not isOPTK:
                    x = {}
                    DeS = {}
                    DeA = {}
                    DeV = {}
                    prundt = {}

                runstart.append(time.time())  

                if Kcon == numnorm - 1:  
                    result.append(KCardTree(rootlis, Kcon, DeS, DeA, DeV, isbrute, galpha, opt, x))
                else:  
                    result.append(KCardTree(rootlis, Kcon, DeS, DeA, DeV, isbrute, galpha, opt, x, False))

                runend.append(time.time() - runstart[len(runstart)-1])  

                # print('MCKP: K =', Kcon, ' RESULT:', result[itr])
                # print('RUNNING TIME:', runend[len(runend)-1])
                common = 0
                N_a = 0
                for idx in result[itr]:
                    if Gpv[int(idx)] < galpha:
                        N_a += 1

                NPSS.append([[result[itr], 0, 0], BJ(galpha, N_a, \
                        len(result[itr])), HC(galpha, N_a, len(result[itr]))])

                i = itr
                # print('K = ', i, 'running time:', runend[i])
                itr += 1  
  
            if app == 'bj':
                opt.Fi = max(opt.Fi, NPSS[len(NPSS)-1][1])  
            if app == 'hc':
                opt.Fi = max(opt.Fi, NPSS[len(NPSS)-1][2])  
        RUNTIME[cc].append(runend)  
    
    sobj = [-1, []]
    sohc = [-1, []]
    for i in range(len(NPSS)):
        if NPSS[i][1] > sobj[0]:
            sobj[0] = NPSS[i][1]
            sobj[1] = NPSS[i][0]
        if NPSS[i][2] > sohc[0]:
            sohc[0] = NPSS[i][2]
            sohc[1] = NPSS[i][0]
    if sobj[0] != -1:
        myfile += 'BJ statistic precision:' + str(sobj[1][1]) + ' recall:' + str(sobj[1][2]) + '\n'
    if sohc[0] != -1:
        myfile += 'HC statistic precision:' + str(sohc[1][1]) + ' recall:' + str(sohc[1][2]) + '\n'
    for cc in range(seednum):
        myfile += 'Time ' + str(cc) + ' buldtreetime ' + str(RUNTIME[cc][0]) + \
                  ' getsolutiontime ' + str(sum(RUNTIME[cc][1])) + ' ' + str(RUNTIME[cc][1]) + '\n'
    if sobj[0] != -1:
        myfile += 'graphbj ' + str(sobj[1][0]) + '\n'
        graphbj = sobj[1][0]
        myfile += 'scorebj ' + str(sobj[0]) + '\n'
    if sohc[0] != -1:
        myfile += 'graphhc ' + str(sohc[1][0]) + '\n'
        graphhc = sohc[1][0]
        myfile += 'scorehc ' + str(sohc[0]) + '\n'
    if len(NPSS) == 0:
        fn = ''

    return [graphbj, graphhc]

def case(time_slice,layer,dataset):
    '''
    attributegraph = AttributeGraph()
    attributegraph.attgraph = {0:{1:0, 2:0, 3:0, 4:0}, 2:{4:0, 5:0, 6:0}, 3:{5:0}, 4:{7:0}, 6:{7:0}}
    attributegraph.att = {0:0.9, 1:0.8, 2:0.01, 3:0.01, 4:0.01, 5:0.02, 6:0.9, 7:0.9}
    return attributegraph
    '''

    attributegraph = AttributeGraph()  
    file1 = open('data/'+dataset+'/attgraph.txt', 'r')
    dic1 = eval(file1.read())
    attributegraph.attgraph = dic1[layer]
    file2 = open('data/'+dataset+'/bj/att.txt', 'r')
    dic2 = eval(file2.read())
    #print(dic2)
    attributegraph.att = dic2[time_slice][time_slice][layer]
    return attributegraph



if __name__ == '__main__':
    time_slice=0
    layer=1
    dataset='Test2'
    ag = case(time_slice,layer,dataset)
    result = budgetK(ag)
    #print 'subgraph-1:', result[0]
    #print 'subgraph-2:', result[1]
    '''
    abc = {}
    abc['time_slice'] = '0'
    abc['non_node'] = result[0]
    file1 = open('./result/result_other.txt', 'a')
    file1.write(str(abc) + ', ')
    file1.close()

    time_slice=0
    layer=0
    ALPHAMAX={0: 0.8154107887062433, 1: 0.8248480475753204, 2: 0.8295506448193312, 3: 0.8380217350878896, 4: 0.8508939222609173, 5: 0.5519059318677025}
    dataset='Network6'
    ag = case(time_slice,layer,dataset)
    result = budgetK(ag,ALPHAMAX[layer])
    print 'subgraph-1:', result[0]
    '''

