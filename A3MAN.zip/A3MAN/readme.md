# A3MAN: Anomaly Alignment Across Multiple Attributed Networks
___
## File Directory
- **A3MAN_BJ.py** --- Main code 
  * **NodeAlignRes** --- records the alignment probability of all node pairs 
    + **i_j_res.txt**--- alignment probabilities of all node pairs between Gi and Gj
  * **data** (DataSet)
    + **Sample**
        + **ALPHAMAX.txt**  --- records the alpha options of different networks
		+ **initalatt.txt**--- records the p-value of all nodes
		+ **multiplex.edges** --- records the edge set of multiple networks 
		+ **bj** --- code execution result folder
			+ **Sstart.txt** --- records the abnomaly subgraphs S*  in each round.
			+ **AlignSstar.txt**  --- records the result of combining the S* of each round with the Si of the previous round
			+ **att.txt ** --- records the update P of each round
			+ **S.txt** ---  records the final aligned anomaly subgraphs Si+1 of each round
		    + **A.txt**  --- records the aligned node pairs of Si+1
  * **Ktree** --- Anomaly Detection Subcode Folder
		*  **ksubg_bj.py**
		* **UnionFind.py**
		* **setting.txt**
		* **__init__.py**
## Operating environment 
         **ubuntu18.02+python2.7**
## Run instructions
        **python A3MAN_BJ.py --dataset Test --sigma 0.8 --alpha 0.15**
## Result File
        **final round data of data/Test/bj/S.txt and data/Test/bj/A.txt**
