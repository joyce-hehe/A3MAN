# -*- coding: utf-8 -*-
"""
Created on Thu Aug  6 09:49:35 2020

@author: zhangjie
"""
import time
import sys
import os
import pandas as pd
from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
from Ktree import ksubg_bj
import networkx as nx


'''
dataset³õÊ¼ÎÄ¼þËµÃ÷£º
multiplex.edges:ÍøÂç¶ÔÆë¸ñÊ½µÄG
layers.txt:´æ·ÅGµÄ²ã´ÎÐÅÏ¢
NodeAlignResÎÄ¼þ¼Ð:´æ·ÅGµÄÈ«¾Ö¶ÔÆëÐÅÏ¢
attgraph.txt:Òì³£¼ì²â¸ñÊ½µÄG
initialatt:Òì³£¼ì²â¸ñÊ½µÄGµÄPvalue
att:´æ·ÅÃ¿´Îµü´úºóGµÄÐÂµÄpvalue
Sstar:´æ·ÅÃ¿´ÎÒì³£¼ì²âºóµÄ×ÓÍ¼¼¯ºÏ
S£º´æ·ÅÃ¿´Îµü´úºóµÄÒì³£µã¼¯ºÏ
A£º´æ·ÅÃ¿´Îµü´úºóµÄÃªÁ´¼¯ºÏ
'''
parser = ArgumentParser("AAAMN",
                          formatter_class=ArgumentDefaultsHelpFormatter,
                          conflict_handler='resolve')
parser.add_argument('--dataset', default='Test', type=str)
parser.add_argument('--alpha', default=0.15, type=float)
parser.add_argument('--sigma', default=0.8, type=float)
args = parser.parse_args()
dataset = args.dataset
bj_out=dataset+'/bj'
Arate = args.alpha
Alignrate=args.sigma
layer=[]

    
'''
½«¶à²ãÍøÂçÎÄ¼þmultiplex.edges×ª»»Îªattgraph¸ñÊ½
'''
def transfile(in_path=None, out_path=None):

    graphs = pd.read_csv(in_path, sep=' ', header=None)
    graphs.columns = ["layerID", "n1", "n2", "weight"]
    G = {}
    for layerID, graph in graphs.groupby(['layerID']):
        layer.append(layerID)
        edges = graph[['n1', 'n2']]
        layedge={}
        for n1id,n12 in edges.groupby(['n1']):
              alln2={}
              for n2 in n12['n2']:
                  alln2[n2]= 0
              layedge[n1id]=alln2
        G[layerID]=layedge
    file1 = open(out_path, 'w')
    file1.write(str(G))
    file1.close()
    return G

'''
³õÊ¼»¯attgraph,S0,S*,att0,A,ALIGNS,¶ÁÈ¡ALPHAMAX*
'''
def init():
    transfile(in_path='data/'+dataset + '/multiplex.edges',   
              out_path='data/'+dataset + '/attgraph.txt'     )
    S={}
    S[0]={}
    for i in layer:
        S[0][i]=[]
    file = open('data/'+bj_out+'/S.txt', 'w')
    file.write(str(S) + ', ')
    file.close()
    
    
    Sstar={}
    Sstar[0]={}
    for i in layer:
        Sstar[0][i]=[]
    filestar = open('data/'+bj_out+'/Sstar.txt', 'w')
    filestar.write(str(Sstar) + ', ')
    filestar.close()
    

    att={}
    file1 = open('data/'+dataset+'/initialatt.txt', 'r')
    dic1 = eval(file1.read())
    att[0]= dic1
    fileatt = open('data/'+bj_out+'/att.txt', 'w')
    fileatt.write(str(att) + ', ')
    fileatt.close()

    fileA = open('data/'+bj_out+'/A.txt', 'w').close()
    fileAS = open('data/'+bj_out+'/AlignSstar.txt', 'w').close()



'''
ÖÕÖ¹Ìõ¼þ£º±È½ÏÇ°ºóÁ½´ÎS(i-1,i)ÊÇ·ñÒ»ÖÂ
'''
    
def halt (i):
    if i<=1:
        return False
    else:
        file = open('data/'+bj_out+'/S.txt', 'r')
        dic = eval(file.read())
        Si = dic[i][i]
        Si_1 = dic[i-1][i-1]
        if Si==Si_1:
            return True
        else:
            return False
'''
¸ù¾ÝS(i+1)¸üÐÂGµÄatt(i+1)
'''
    
def updateG(i,layer):
    
    att_iplus1={}
    file1 = open('data/'+bj_out+'/att.txt', 'r')
    dic1  = eval(file1.read())
    atti=dic1[i][i]
    file2 = open('data/'+bj_out+'/S.txt', 'r')
    dic2  = eval(file2.read())
    S_iplus1=dic2[i+1][i+1]
    for li in layer:
        for node in S_iplus1[li]:
            atti[li][node]=1.0
    att_iplus1[i+1]=atti
    fileatt = open('data/'+bj_out+'/att.txt', 'a')
    fileatt.write(str(att_iplus1) + ', ')
    fileatt.close()
    
    

'''
Êä³ö±¾´ÎÒì³£×ÓÍ¼½á¹ûS*_i+1µ½ÎÄ¼þS*.txt
'''
def ksubgraph(i,layer,dataset,ALPHAMAX):
    sstari={}
    sres={}
    for layerj in layer:
      ag = ksubg_bj.case(i,layerj,dataset)
      #print(layerj)
      #print(ALPHAMAX[layerj])
      result = ksubg_bj.budgetK(ag,ALPHAMAX[layerj])
      sres[layerj]=result[0]
    sstari[i+1]=sres
    file = open('data/'+bj_out+'/Sstar.txt', 'a')
    file.write(str(sstari) + ', ')
    file.close()
'''
½«S*_i+1ÓëÉÏ´ÎµÄSiºÏ²¢ÓÃÒÔ¶ÔÆë¹¤×÷
'''
def union(i,layer):
    
    SstarforAligni={}
    SstarforAlign={}
    file1 = open('data/'+bj_out+'/Sstar.txt', 'r')
    dic1 = eval(file1.read())
    Ssarti=dic1[i+1][i+1]
    if(i>0):
        file2 = open('data/'+bj_out+'/S.txt', 'r')
        dic2 = eval(file2.read())
        Si_1=dic2[i][i]
        for layerj in layer:
            tmp=Ssarti[layerj]+Si_1[layerj]
            tmp=list(set(tmp))
            SstarforAligni[layerj]=tmp
        file2.close()
    elif(i==0):
        SstarforAligni=Ssarti
    SstarforAlign[i+1]=SstarforAligni
    file1.close()
   
    #¿´Çé¿öÊä³ö
    file = open('./data/'+bj_out+'/AlignSstar.txt', 'a')
    file.write(str(SstarforAlign) + ', ')
    file.close()
   
    return SstarforAligni
            

def align(i,layer):

    SstarforAligni=union(i,layer)
    S={}
    Si={}
    A={}
    Ai={}
    for layeri in layer:
        Si[layeri]=[]
        Ai[layeri]={}
        for nodei in SstarforAligni[layeri]: 
            Ai[layeri][nodei]={}
            for layerj in layer:
                if layeri!=layerj:
                    Ai[layeri][nodei][layerj]=[]
    for layeri in layer:
        for layerj in layer:
            if layeri!=layerj and layeri<layerj :
                file = open('data/'+dataset+'/NodeAlignRes/'+str(layeri)+'_'+str(layerj)+'_res.txt', 'r')
                dic = eval(file.read())
                for nodei in SstarforAligni[layeri]: 
                    for nodej in SstarforAligni[layerj]:
                        #print(layeri,layerj,nodei,nodej)
                        #if nodej in dic[nodei].keys() and dic[nodei][nodej]>=dic['meanp']:
                        if nodej in dic[nodei].keys() and dic[nodei][nodej]>=Alignrate:
                            Si[layeri].append(nodei)
                            Si[layerj].append(nodej)
                            if nodej not in Ai[layeri][nodei][layerj]:
                                Ai[layeri][nodei][layerj].append(nodej)
                            if nodei not in Ai[layerj][nodej][layeri]:
                                Ai[layerj][nodej][layeri].append(nodei)
    for layeri in layer:
        for nodei in list(Ai[layeri].keys()):
            for layerj in layer:
                if layerj!=layeri and Ai[layeri][nodei][layerj]==[]:
                    del Ai[layeri][nodei][layerj]
            if Ai[layeri][nodei]=={}:
                del Ai[layeri][nodei]
    '''
    for layeri in layer:
        for nodei in list(Ai[layeri].keys())
            if Ai[layeri][nodei]=={}:
                del Ai[layeri][nodei]
    for layeri in layer:
        if Ai[layeri]=={}:
            del Ai[layeri]
    '''

    
    for layeri in layer:
        Si[layeri]=list(set(Si[layeri]))
    S[i+1]=Si
    files = open('data/'+bj_out+'/S.txt', 'a')
    files.write(str(S) + ', ')
    files.close()
    A[i+1]=Ai
    filea = open('data/'+bj_out+'/A.txt', 'a')
    filea.write(str(A) + ', ')
    filea.close()
        
    
    
if __name__ == '__main__':  

    start_time = time.clock()
    i=0
    init()
    #'''
    ALPHAMAX={}
    fa = open('data/'+dataset+'/ALPHAMAX.txt', 'r')
    dica = eval(fa.read())
    ALPHAMAX= dica[Arate]
    print('init complete!')
    while(halt(i) == False or i > 500):
        ksubgraph(i,layer,dataset,ALPHAMAX)
        union(i,layer)
        align(i,layer)
        updateG(i,layer)
        print(str(i+1)+'th epoch complete!')
        i=i+1
    end_time = time.clock()
    print('time for main {0} s'.format(end_time - start_time))
    #'''
        
